<template>
  <div class="leftButton">
    <router-link :to="link">{{ msg }} <br/><img src="@/assets/leftArrow.png" alt="Arrow to go to the left"/></router-link>
  </div>
</template>

<script>
export default {
  name: 'LeftButton',
  props: {
    msg: String,
    link: String,
  },
};
</script>

<style scoped lang="scss">
.leftButton {
  width: 100px;
  text-align: center;
  a {
    color: white;
    font-weight: bold;
    text-shadow:
      0 0 5px #fff,
      0 0 10px #fff,
      0 0 20px #fff,
      0 0 40px #0ff,
      0 0 80px #0ff,
      0 0 90px #0ff,
      0 0 100px #0ff,
      0 0 150px #0ff;
    font-size: 16px;
    animation: shine 1.5s linear infinite;
  }
  @keyframes shine {
    0%{
      opacity: 1;
    }
    50%{
      opacity: 0.7;
    }
    100%{
      opacity: 1;
    }
  }
  img {
    width: 30px;
    height: 30px;
    margin-top: 10px
  }
}
</style>
