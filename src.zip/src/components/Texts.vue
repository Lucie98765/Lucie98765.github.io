<template>
  <div class="textBox">
    <p :style="style">{{ msg }}</p>
  </div>
</template>

<script>
export default {
  name: 'Texts',
  props: {
    msg: String,
  },
  data() {
    let randomX = Math.floor(Math.random() * (window.innerWidth - 200) + 200);
    if (randomX > (window.innerWidth - 200)) {
      randomX -= 200;
    }
    let randomY = Math.floor(Math.random() * (window.innerHeight - 200) + 200);
    if (randomY > (window.innerHeight - 200)) {
      randomY -= 200;
    }
    return {
      style: `top: ${randomY}px; left: ${randomX}px;`,
    };
  },
};
</script>

<style scoped lang="scss">
.textBox {
    height: 100vh;
    width: 100vw;
    position: absolute;
    top: 0;
    left: 0;
    pointer-events: none;
}
p {
  position: absolute;
  color: white;
  font-weight: bold;
  text-shadow:
    0 0 5px #fff,
    0 0 10px #fff,
    0 0 20px #fff,
    0 0 40px #0ff,
    0 0 80px #0ff,
    0 0 90px #0ff,
    0 0 100px #0ff,
    0 0 150px #0ff;
  font-size: 20px;
  animation: shine 1.5s linear infinite;
  padding: 10px;
}
@keyframes shine{
   0%{
     opacity: 1;
   }
   50%{
     opacity: 0.7;
   }
   100%{
     opacity: 1;
   }
 }
</style>
