<template>
  <div class="Character">
    <!--<h1>Le ptit perso</h1>-->
    <img src="@/assets/character.png" alt="the character">
  </div>
</template>

<script>
export default {
  name: 'Character',
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
img {
  height: 200px;
}
</style>
