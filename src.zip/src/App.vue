<template>
  <div id="app">
    <transition name="component-fade" mode="out-in">
      <router-view/>
    </transition>
    <audio id="music" autoplay="autoplay" loop="loop">
      <source src="@/assets/sounds/spheria-otjanbird-ptiii.mp3" type="audio/mpeg">
      <!-- <source src="@/assets/sounds/spheria-otjanbird-ptiii.mp3" type="audio/mp3">
      <source src="@/assets/sounds/spheria-otjanbird-ptiii.mp3" type="audio/ogg"> -->
    </audio>
    <!--
      Musique proposée par La Musique Libre, composée par Spheriá
      Spheriá - Otjánbird Pt.III : https://youtu.be/kx7hq3uiwFQ
      Spheriá : https://soundcloud.com/spheriamusic
    -->
  </div>
</template>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

* {
  margin: 0;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
.component-fade-enter-active, .component-fade-leave-active {
  transition: opacity .3s ease;
}
.component-fade-enter, .component-fade-leave-to {
  opacity: 0;
}
#music {
  display: none;
}
</style>
