import Vue from 'vue';
import VueRouter from 'vue-router';
import Home from '../views/Home.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
  },
  {
    path: '/clairiere',
    name: 'Clairiere',
    component: () => import('../views/Clairiere.vue'),
  },
  {
    path: '/foret',
    name: 'Foret',
    component: () => import('../views/Foret.vue'),
  },
  {
    path: '/grotte',
    name: 'Grotte',
    component: () => import('../views/Grotte.vue'),
  },
  {
    path: '/mer',
    name: 'Mer',
    component: () => import('../views/Mer.vue'),
  },
  {
    path: '/montagne',
    name: 'Montagne',
    component: () => import('../views/Montagne.vue'),
  },
  {
    path: '/riviere',
    name: 'Riviere',
    component: () => import('../views/Riviere.vue'),
  },
  {
    path: '/caveHouse',
    name: 'GrotteMaison',
    component: () => import('../views/GrotteMaison.vue'),
  },
  {
    path: '/riverHouse',
    name: 'RiviereMaison',
    component: () => import('../views/RiviereMaison.vue'),
  },
  {
    path: '/moutainHouse',
    name: 'MontagneMaison',
    component: () => import('../views/MontagneMaison.vue'),
  },
  {
    path: '/seaHouse',
    name: 'MerMaison',
    component: () => import('../views/MerMaison.vue'),
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
