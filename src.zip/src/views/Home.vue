<template>
  <div class="home">
    <h1>Forêt ou clairière ?</h1>
    <div id="text_box">
      <p id="text1">Où... Où suis je ?</p>
      <p id="text2">J'ai dû m'endormir ici...</p>
      <p id="text3">Il faut que je retrouve mon chemin, il faut que je rentre chez moi</p>
    </div>
    <div id="button_box">
      <div id="buttons">
        <LeftButton msg="Aller vers la forêt" link="/foret" class="buttons"/>
        <RightButton msg="Aller vers la clairière" link="/clairiere" class="buttons"/>
      </div>
      <!--<Character id="character"/>-->
    </div>
  </div>
</template>

<script>
import LeftButton from '@/components/LeftButton.vue';
import RightButton from '@/components/RightButton.vue';
// import Character from '@/components/Character.vue';

export default {
  name: 'Home',
  components: {
    LeftButton,
    RightButton,
    // Character,
  },
};
</script>

<style scoped lang="scss">
.home{
  background-color: rgb(4, 4, 22);
  height: 100vh;
  width: 100vw;
  margin: 0;
  padding: 0;
  animation: fadeIn 3s linear;

  @keyframes fadeIn{
    0%{
      opacity: 0;
    }
    75%{
      opacity: 0;
    }
    100%{
      opacity: 1;
    }
  }
  h1 {
    display: none;
  }

  #text_box {
    display: flex;
    flex-direction: column;
    height: 100vh;
    width: 100vw;
    margin: 0;
    padding: 0;
    justify-content: center;

    p {
      margin: 2vh;
      color: white;
      font-weight: bold;
      text-shadow:
        0 0 5px #fff,
        0 0 10px #fff,
        0 0 20px #0ff,
        0 0 40px #0ff;
      font-size: 20px;
    }

    #text1{
      animation: fadeInText1 4s linear;
    }

    @keyframes fadeInText1{
      0%{
        opacity: 0;
      }
      75%{
        opacity: 0;
      }
      100%{
        opacity: 1;
      }
    }

    #text2{
      animation: fadeInText2 6s linear;
    }

    @keyframes fadeInText2{
      0%{
        opacity: 0;
      }
      75%{
        opacity: 0;
      }
      100%{
        opacity: 1;
      }
    }

    #text3{
      animation: fadeInText2 8s linear;
    }

    @keyframes fadeInText3{
      0%{
        opacity: 0;
      }
      75%{
        opacity: 0;
      }
      100%{
        opacity: 1;
      }
    }
  }
}
</style>

<style lang="scss">
body {
  background-color: rgb(4, 4, 22);;
}
#button_box {
  position: absolute;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  #character {
    position: absolute;
    bottom: 3vh;
    left: 45vw;
  }
  #buttons {
    width: 100vw;
    height: 100vh;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  }
  #buttons>* {
    margin: 10px;
  }
}
</style>
