<template>
  <div class="river">
    <h1>River page</h1>
    <div id="image_box">
      <img src="@/assets/river/fish1.png" alt="first fish" id="fish1" class="fishes">
      <img src="@/assets/river/fish2.png" alt="second fish" id="fish2" class="fishes">
      <img src="@/assets/river/fish3.png" alt="third fish" id="fish3" class="fishes">
      <img src="@/assets/river/fish4.png" alt="fourth fish" id="fish4" class="fishes">
    </div>
    <div id="button_box">
      <div id="buttons">
        <RightButton msg="Continuer d'avancer" link="/riverHouse" class="buttons"/>
      </div>
      <Character id="character"/>
    </div>
    <Texts msg="Ca grouille de poissons par ici..." id="text1" class="textComponent"/>
    <Texts msg="La végétation s'est modifiée, c'est plus humique" id="text2" class="textComponent"/>
  </div>
</template>

<script>
import RightButton from '@/components/RightButton.vue';
import Character from '@/components/Character.vue';
import Texts from '@/components/Texts.vue';

export default {
  name: 'River',
  components: {
    RightButton,
    Character,
    Texts,
  },
  mounted: () => {
    const randomTime1 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text1 = document.getElementById('text1');
    setTimeout(() => {
      text1.style.display = 'block';
    }, randomTime1);

    const randomTime2 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text2 = document.getElementById('text2');
    setTimeout(() => {
      text2.style.display = 'block';
    }, randomTime2);
  },
};
</script>

<style scoped lang="scss">
.river {
  overflow: hidden;
  position: relative;
  h1 {
    display: none;
  }
  #image_box {
    width: 100vw;
    height: 100vh;
    position: relative;
    background-image: url('../assets/river/river.png');
    background-position: center;
    background-size: cover;
    .large {
      width: 100%;
      max-height: 100%;
      position: absolute;
      top: 0;
      left: 0;
    }
    .fishes {
      position: absolute;
      z-index: 3;
    }
    .fishes:hover {
      animation: rotation 2s ease-out infinite;
    }
    @keyframes rotation {
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(359deg);
      }
    }
    #fish1 {
      bottom: 1vh;
      left: 15vw;
      width: 70px;
      transform-origin: 30px bottom;
    }
    #fish2 {
      bottom: 2vh;
      left: 40vw;
      width: 50px;
      transform-origin: 10px bottom;
    }
    #fish3 {
      bottom: 1vh;
      right: 33vw;
      width: 75px;
      transform-origin: 30px bottom;
    }
    #fish4 {
      bottom: 1vh;
      right: 18vw;
      width: 60px;
      transform-origin: 20px bottom;
    }
  }
  .textComponent {
    transition: all 1s ease-out;
    display: none;
    z-index: 4;
  }
  #buttons {
    justify-content: flex-end!important;
  }
  #character {
    margin-bottom: 10vh;
  }
}
</style>
