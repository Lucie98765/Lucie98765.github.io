<template>
  <div class="clearing">
    <h1>Clearing page</h1>
    <div id="image_box">
      <img src="@/assets/clearing/flower1.png" alt="first flower" id="flower1" class="flowers">
      <img src="@/assets/clearing/flower2.png" alt="second flower" id="flower2" class="flowers">
      <img src="@/assets/clearing/flower3.png" alt="third flower" id="flower3" class="flowers">
      <img src="@/assets/clearing/flower4.png" alt="fourth flower" id="flower4" class="flowers">
      <img src="@/assets/clearing/flower5.png" alt="fifth flower" id="flower5" class="flowers">
      <img src="@/assets/clearing/flower6.png" alt="sixth flower" id="flower6" class="flowers">
      <img src="@/assets/clearing/flower7.png" alt="seventh flower" id="flower7" class="flowers">
    </div>
    <div id="button_box">
      <div id="buttons">
        <LeftButton msg="Aller vers la montagne" link="/montagne" class="buttons"/>
        <RightButton msg="Aller vers la mer" link="/mer" class="buttons"/>
      </div>
      <Character id="character"/>
    </div>
    <Texts msg="C'est la saison des coquelicots on dirait" id="text1" class="textComponent"/>
    <Texts msg="Mes fleurs préférées" id="text2" class="textComponent"/>
  </div>
</template>

<script>
import LeftButton from '@/components/LeftButton.vue';
import RightButton from '@/components/RightButton.vue';
import Character from '@/components/Character.vue';
import Texts from '@/components/Texts.vue';

export default {
  name: 'Clearing',
  components: {
    LeftButton,
    RightButton,
    Character,
    Texts,
  },
  mounted: () => {
    const randomTime1 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text1 = document.getElementById('text1');
    setTimeout(() => {
      text1.style.display = 'block';
    }, randomTime1);

    const randomTime2 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text2 = document.getElementById('text2');
    setTimeout(() => {
      text2.style.display = 'block';
    }, randomTime2);
  },
};
</script>

<style scoped lang="scss">
.clearing {
  overflow: hidden;
  position: relative;
  h1 {
    display: none;
  }
  #image_box {
    width: 100vw;
    height: 100vh;
    position: relative;
    background-image: url('../assets/clearing/clearing.png');
    background-position: center;
    background-size: cover;
    .large {
      width: 100%;
      max-height: 100%;
      position: absolute;
      top: 0;
      left: 0;
    }
    .flowers {
      position: absolute;
      z-index: 3;
    }
    .flowers:hover {
      animation: rotation 2s ease-out infinite;
    }
    @keyframes rotation {
      0% {
        transform: rotate(0deg);
      }
      25% {
        transform: rotate(10deg);
      }
      75% {
        transform: rotate(-10deg);
      }
      100% {
        transform: rotate(0deg);
      }
    }
    #flower1 {
      bottom: 0;
      left: 7vw;
      width: 30px;
    }
    #flower2 {
      bottom: 5vh;
      left: 16vw;
      width: 40px;
    }
    #flower3 {
      bottom: 0;
      left: 25vw;
      width: 27px;
    }
    #flower4 {
      bottom: 0;
      left: 40vw;
      width: 35px;
    }
    #flower5 {
      bottom: 0;
      left: 55vw;
      width: 40px;
    }
    #flower6 {
      bottom: 0;
      left: 70vw;
      width: 27px;
    }
    #flower7 {
      bottom: 0;
      left: 92vw;
      width: 35px;
    }
  }
  .textComponent {
    transition: all 1s ease-out;
    display: none;
    z-index: 4;
  }
}
</style>
