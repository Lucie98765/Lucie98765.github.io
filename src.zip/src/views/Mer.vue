<template>
  <div class="sea">
    <h1>Sea page</h1>
    <div id="image_box">
      <img src="@/assets/sea/crab1.png" alt="first crab" id="crab1" class="crabs" v-on:click="stepAside('crab1')">
      <img src="@/assets/sea/crab2.png" alt="second crab" id="crab2" class="crabs" v-on:click="stepAside('crab2')">
      <img src="@/assets/sea/crab3.png" alt="third crab" id="crab3" class="crabs" v-on:click="stepAside('crab3')">
    </div>
    <div id="button_box">
      <div id="buttons">
        <RightButton msg="Continuer d'avancer" link="/seaHouse" class="buttons"/>
      </div>
      <Character id="character"/>
    </div>
    <Texts msg="Ca sent bon la mer..." id="text1" class="textComponent"/>
    <Texts msg="Le soleil se couche, c'est magnifique !" id="text2" class="textComponent"/>
  </div>
</template>

<script>
import RightButton from '@/components/RightButton.vue';
import Character from '@/components/Character.vue';
import Texts from '@/components/Texts.vue';

export default {
  name: 'River',
  components: {
    RightButton,
    Character,
    Texts,
  },
  mounted: () => {
    const randomTime1 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text1 = document.getElementById('text1');
    setTimeout(() => {
      text1.style.display = 'block';
    }, randomTime1);

    const randomTime2 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text2 = document.getElementById('text2');
    setTimeout(() => {
      text2.style.display = 'block';
    }, randomTime2);
  },
  methods: {
    stepAside(id) {
      const crab = document.getElementById(id);
      const x = crab.offsetLeft;
      const y = crab.offsetTop;
      console.log(x, y);
      if (id === 'crab1') {
        crab.animate([
          {
            transform: 'translate(0px, 0px)',
          },
          {
            transform: `translate(${x - 15}px, ${y - 3}px)`,
          },
        ], {
          duration: 3000,
          easing: 'ease-out',
          iterations: 2,
          direction: 'alternate',
        });
      } else if (id === 'crab2') {
        crab.animate([
          {
            transform: 'translate(0px, 0px)',
          },
          {
            transform: `translate(${x + 5}px, ${y - 1}px)`,
          },
        ], {
          duration: 3000,
          easing: 'ease-out',
          iterations: 2,
          direction: 'alternate',
        });
      } else if (id === 'crab3') {
        crab.animate([
          {
            transform: 'translateX(0px)',
          },
          {
            transform: `translateX(${x + 10}px)`,
          },
        ], {
          duration: 3000,
          easing: 'ease-out',
          iterations: 2,
          direction: 'alternate',
        });
      }
    },
  },
};
</script>

<style scoped lang="scss">
.sea {
  overflow: hidden;
  position: relative;
  h1 {
    display: none;
  }
  #image_box {
    width: 100vw;
    height: 100vh;
    position: relative;
    background-image: url('../assets/sea/sea.png');
    background-position: center;
    background-size: cover;
    .large {
      width: 100%;
      max-height: 100%;
      position: absolute;
      top: 0;
      left: 0;
    }
    .crabs {
      position: absolute;
      z-index: 3;
    }
    .fishes:hover {
      animation: rotation 2s ease-out infinite;
    }
    @keyframes rotation {
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(359deg);
      }
    }
    #crab1 {
      bottom: 3vh;
      left: 15vw;
      width: 70px;
      transform-origin: 30px bottom;
    }
    #crab2 {
      bottom: 2vh;
      left: 60vw;
      width: 50px;
      transform-origin: 10px bottom;
    }
    #crab3 {
      bottom: 3vh;
      right: 11vw;
      width: 55px;
      transform-origin: 30px bottom;
    }
  }
  .textComponent {
    transition: all 1s ease-out;
    display: none;
    z-index: 4;
  }
  #buttons {
    justify-content: flex-end!important;
  }
}
</style>
