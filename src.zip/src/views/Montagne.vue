<template>
  <div class="moutain"  @click="letItSnow($event)">
    <h1>Moutain page</h1>
    <div id="image_box"></div>
    <div id="button_box">
      <div id="buttons">
        <RightButton msg="Continuer d'avancer" link="/moutainHouse" class="buttons"/>
      </div>
      <Character id="character"/>
    </div>
    <Texts msg="Brrrr... J'aurais dû prendre mon bonnet" id="text1" class="textComponent"/>
    <Texts msg="On dirait qu'il va bientôt neiger" id="text2" class="textComponent"/>
  </div>
</template>

<script>
import RightButton from '@/components/RightButton.vue';
import Character from '@/components/Character.vue';
import Texts from '@/components/Texts.vue';

export default {
  name: 'Moutain',
  components: {
    RightButton,
    Character,
    Texts,
  },
  mounted: () => {
    const randomTime1 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text1 = document.getElementById('text1');
    setTimeout(() => {
      text1.style.display = 'block';
    }, randomTime1);

    const randomTime2 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text2 = document.getElementById('text2');
    setTimeout(() => {
      text2.style.display = 'block';
    }, randomTime2);
  },
  methods: {
    letItSnow(event) {
      const y = event.pageY;
      const x = event.pageX;

      for (let i = 0; i < 30; i += 1) {
        const particle = document.createElement('div');
        particle.className = 'snow';
        document.getElementById('image_box').appendChild(particle);
        // Calculate a random size from 5px to 25px and apply it to each particle
        const size = Math.floor(Math.random() * 10 + 5);
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        // Generate a random color in a blue/purple palette
        particle.style.background = 'rgba(255, 255, 255, 0.6)';
        particle.style.borderRadius = '50%';
        // Generate a random x & y destination within a distance of 30px from the mouse
        const destinationX = x + (Math.random() - 0.5) * 2 * 30;
        const destinationY = y + (Math.random() - 0.5) * 2 * 30;
        // Store the animation in a variable because we will need it later
        const animation = particle.animate([
          {
            // Set the origin position of the particle
            // We offset the particle with half its size to center it around the mouse
            transform: `translate(${x - (size / 2)}px, ${y - (size / 2)}px)`,
            opacity: 1,
          },
          {
            // We define the final coordinates as the second keyframe
            transform: `translate(${destinationX}px, ${destinationY}px)`,
            opacity: 0,
          },
        ], {
          duration: 2000,
          easing: 'cubic-bezier(0, .9, .57, 1)',
        });
        document.querySelector('.moutain').style.pointerEvents = 'none';
        animation.onfinish = () => {
          particle.remove();
          document.querySelector('.moutain').style.pointerEvents = 'all';
        };
      }
    },
  },
};
</script>

<style scoped lang="scss">
.moutain {
  overflow: hidden;
  position: relative;
  h1 {
    display: none;
  }
  #image_box {
    width: 100vw;
    height: 100vh;
    position: relative;
    background-image: url('../assets/moutain/moutain.png');
    background-position: center;
    background-size: cover;
    .large {
      width: 100%;
      max-height: 100%;
      position: absolute;
      top: 0;
      left: 0;
    }
  }
  .textComponent {
    transition: all 1s ease-out;
    display: none;
    z-index: 4;
  }
  #buttons {
    justify-content: flex-end!important;
  }
  .snow {
    border-radius: 50%;
    left: 0;
    pointer-events: none;
    position: fixed;
    top: 0;
    opacity: 0;
    z-index: 6;
  }
}
</style>
