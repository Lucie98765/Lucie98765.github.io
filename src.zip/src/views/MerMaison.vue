<template>
  <div class="seaHouse">
    <h1>Sea House page</h1>
    <div id="image_box">
    </div>
    <Texts msg="Grâce à toi j'ai retrouvé ma maison" id="text2" class="textComponent"/>
    <Texts msg="Merci" id="text3" class="textComponent"/>
    <div id="button_box">
      <div id="buttons">
        <RightButton msg="Retourner au début" link="/" class="buttons"/>
      </div>
    </div>
  </div>
</template>

<script>
import Texts from '@/components/Texts.vue';
import RightButton from '@/components/RightButton.vue';

export default {
  name: 'CaveHouse',
  components: {
    Texts,
    RightButton,
  },
  mounted: () => {
    const randomTime2 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text2 = document.getElementById('text2');
    setTimeout(() => {
      text2.style.display = 'block';
    }, randomTime2);

    const randomTime3 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text3 = document.getElementById('text3');
    setTimeout(() => {
      text3.style.display = 'block';
    }, randomTime3);
  },
};
</script>

<style scoped lang="scss">
.seaHouse {
  overflow: hidden;
  position: relative;
  h1 {
    display: none;
  }
  #image_box {
    width: 100vw;
    height: 100vh;
    position: relative;
    background-image: url('../assets/sea/seaHouse.png');
    background-position: center;
    background-size: cover;
  }
.textComponent {
    transition: all 1s ease-out;
    display: none;
    z-index: 4;
  }
  #buttons {
    justify-content: flex-end!important;
    animation: fadeIn 5s linear;
  }
  @keyframes fadeIn{
    0%{
      opacity: 0;
    }
    75%{
      opacity: 0;
    }
    100%{
      opacity: 1;
    }
  }
}
</style>
