<template>
  <div class="forest">
    <h1>Forest page</h1>
    <div id="image_box">
      <img src="@/assets/forest/eyes1.png" alt="first pair of eyes" id="eye1" class="eyes" v-on:click="blink('eye1')">
      <img src="@/assets/forest/eyes2.png" alt="second pair of eyes" id="eye2" class="eyes" v-on:click="blink('eye2')">
      <img src="@/assets/forest/eyes3.png" alt="third pair of eyes" id="eye3" class="eyes" v-on:click="blink('eye3')">
    </div>
    <div id="button_box">
      <div id="buttons">
        <LeftButton msg="Aller vers la grotte" link="/grotte" class="buttons"/>
        <RightButton msg="Aller vers la rivière" link="/riviere" class="buttons"/>
      </div>
      <Character id="character"/>
    </div>
    <Texts msg="Les hiboux sont nombreux ce soir" id="text2" class="textComponent"/>
    <Texts msg="Ils me parlent, je les entends" id="text3" class="textComponent"/>
    <div class="hide">
      <audio id="audio1">
        <source src="@/assets/sounds/owl_1.mp3" type="audio/mpeg">
      </audio>
      <audio id="audio2">
        <source src="@/assets/sounds/owl_2.mp3" type="audio/mpeg">
      </audio>
    </div>
  </div>
</template>

<script>
import LeftButton from '@/components/LeftButton.vue';
import RightButton from '@/components/RightButton.vue';
import Character from '@/components/Character.vue';
import Texts from '@/components/Texts.vue';

export default {
  name: 'Forest',
  components: {
    LeftButton,
    RightButton,
    Character,
    Texts,
  },
  methods: {
    blink(id) {
      const random = Math.floor(Math.random() * 2);
      console.log(random);
      if (random === 0) {
        const audio1 = document.getElementById('audio1');
        audio1.play();
      } else {
        const audio2 = document.getElementById('audio2');
        audio2.play();
      }
      const eye = document.getElementById(id);
      setTimeout(() => {
        eye.style.display = 'none';
        setTimeout(() => {
          eye.style.display = 'block';
          setTimeout(() => {
            eye.style.display = 'none';
            setTimeout(() => {
              eye.style.display = 'block';
            }, 500);
          }, 300);
        }, 300);
      }, 200);
    },
  },
  mounted: () => {
    const randomTime2 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text2 = document.getElementById('text2');
    setTimeout(() => {
      text2.style.display = 'block';
    }, randomTime2);

    const randomTime3 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text3 = document.getElementById('text3');
    setTimeout(() => {
      text3.style.display = 'block';
    }, randomTime3);
  },
};
</script>

<style scoped lang="scss">
.forest {
  overflow: hidden;
  position: relative;
  h1 {
    display: none;
  }
  #image_box {
    width: 100vw;
    height: 100vh;
    position: relative;
    background-image: url('../assets/forest/forest.png');
    background-position: center;
    background-size: cover;
    .large {
      width: 100%;
      max-height: 100%;
      position: absolute;
      top: 0;
      left: 0;
    }
    .eyes {
      position: absolute;
      z-index: 3;
    }
    #eye1 {
      top: 8vh;
      left: 3vw;
    }
    #eye2 {
      top: 15vh;
      right: 9vw;
    }
    #eye3 {
      bottom: 12vw;
      left: 70vw;
    }
  }
  /* #button_box {
    position: absolute;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    #character {
      position: absolute;
      bottom: 3vh;
      left: 45vw;
    }
    #buttons {
      width: 100vw;
      height: 100vh;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
    }
    #buttons>* {
      margin: 10px;
    }
  } */
  .hide {
    display: none;
  }
  .textComponent {
    transition: all 1s ease-out;
    display: none;
    z-index: 4;
  }
}
</style>
