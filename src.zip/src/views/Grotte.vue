<template>
  <div class="cave"  @mousemove="getCursor($event)">
    <h1>Cave page</h1>
    <div id="image_box">
      <img src="@/assets/cave/bullock.png" alt="bullock painting" id="bullock" class="paintings">
      <img src="@/assets/cave/horse.png" alt="horse painting" id="horse" class="paintings">
      <img src="@/assets/cave/hand.png" alt="hand painting" id="hand" class="paintings">
    </div>
    <div id="button_box">
      <div id="buttons">
        <RightButton msg="Continuer d'avancer" link="/caveHouse" class="buttons"/>
      </div>
      <Character id="character"/>
    </div>
    <Texts msg="Il fait plus frais ici..." id="text1" class="textComponent"/>
    <Texts msg="Ces fresques sont incroyables !" id="text2" class="textComponent"/>
    <div id="circle"></div>
  </div>
</template>

<script>
import RightButton from '@/components/RightButton.vue';
import Character from '@/components/Character.vue';
import Texts from '@/components/Texts.vue';

export default {
  name: 'Cave',
  components: {
    RightButton,
    Character,
    Texts,
  },
  mounted: () => {
    const randomTime1 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text1 = document.getElementById('text1');
    setTimeout(() => {
      text1.style.display = 'block';
    }, randomTime1);

    const randomTime2 = 1000 * (1 + (Math.floor(Math.random() * 5)));
    const text2 = document.getElementById('text2');
    setTimeout(() => {
      text2.style.display = 'block';
    }, randomTime2);
  },
  methods: {
    getCursor(event) {
      const cursor = document.getElementById('circle');
      const top = event.pageY - (cursor.clientHeight / 2);
      const left = event.pageX - (cursor.clientWidth / 2);
      cursor.style.top = `${top}px`;
      cursor.style.left = `${left}px`;
    },
  },
};
</script>

<style scoped lang="scss">
.cave {
  overflow: hidden;
  position: relative;
  h1 {
    display: none;
  }
  #image_box {
    width: 100vw;
    height: 100vh;
    position: relative;
    background-image: url('../assets/cave/cave.png');
    background-position: center;
    background-size: cover;
    filter: brightness(30%);
    .large {
      width: 100%;
      max-height: 100%;
      position: absolute;
      top: 0;
      left: 0;
    }
    .paintings {
      position: absolute;
    }
    #bullock {
      top: 20vh;
      right: 18vw;
      width: 20vw;
    }
    #horse {
      top: 40vh;
      left: 18vw;
      width: 22vw;
    }
    #hand {
      bottom: 25vh;
      right: 28vw;
      width: 4vw;
    }
  }
  .textComponent {
    transition: all 1s ease-out;
    display: none;
    z-index: 4;
  }
  #buttons {
    justify-content: flex-end!important;
  }
  #circle {
    position: absolute;
    width: 200px;
    height: 200px;
    top: 50%;
    left: 50%;
    border-radius: 100%;
    transition: transform .5s;
    z-index: 99;
    background-color: rgba(200, 183, 30, 0.2);
    filter: blur(10px);
    pointer-events: none;
  }
}
</style>
